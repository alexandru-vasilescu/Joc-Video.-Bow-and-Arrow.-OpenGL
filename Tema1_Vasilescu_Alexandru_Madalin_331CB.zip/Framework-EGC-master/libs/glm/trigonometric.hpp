/// @ref core
/// @file glm/trigonometric.hpp

#pragma once

#include "detail/func_trigonometric.hpp"
