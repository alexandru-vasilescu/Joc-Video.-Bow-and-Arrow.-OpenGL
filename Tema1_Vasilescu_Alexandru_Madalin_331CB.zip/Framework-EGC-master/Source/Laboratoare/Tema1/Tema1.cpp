#include "Tema1.h"
#include "Transform2D.h"
using namespace std;
using namespace glm;
Tema1::Tema1(){}
Tema1::~Tema1(){}


vector<VertexFormat> bow_form(vec3 color,float a,float b)
{
	vector<VertexFormat> v;
	float x, y=1.0;
	while(y>-1)
	{
		x = a/b*sqrt(b*b - y * y);
		v.push_back(VertexFormat(vec3(x, y, 0), color));
		y -= 0.01;
	}
	return v;
}
vector<VertexFormat> balloon_v(vec3 color,float a, float b)
{
	vector<VertexFormat> v;
	float dist_intre_puncte = 0.01;
	float x = 1, y;
	while(x > -1)
	{
		y = b/a*sqrt(a*a - x * x);
		v.push_back(VertexFormat(vec3(x, y, 0), color));
		x -= dist_intre_puncte;
	}
	while(x < 1)
	{
		y = -b/a*sqrt(a*a - x * x);
		v.push_back(VertexFormat(vec3(x, y, 0), color));
		x += dist_intre_puncte;
	}
	return v;
}
vector<VertexFormat> balloon_tail(vec3 color)
{
	float z = 0.25;
	vector < VertexFormat> v;
	float x = 0, y = -2;
	for(int i=0;i<5;i++)
	{
		v.push_back(VertexFormat(vec3(x, y, 0), color));
		if (x == 0 || x == -z)
			x = z;
		else x = -z;
		y -= 2*z;
	}
	return v;
}
Mesh *balloon(vec3 color,string name)
{
	vector<VertexFormat> rb_v = balloon_v(color, 1, 1.75);
	vector<unsigned short> rb_i;
	rb_i.push_back(0);
	for (int i = 1; i < rb_v.size(); i++)
		rb_i.push_back(i);
	Mesh* rb = new Mesh(name);
	rb->SetDrawMode(GL_TRIANGLE_FAN);
	rb->InitFromData(rb_v, rb_i);
	return rb;
}
Mesh *balloon_Triangle(vec3 color,string name)
{
	vector<VertexFormat> tr_v{
			VertexFormat(vec3(0, -1.6, 0), color),
			VertexFormat(vec3(-0.5, -2, 0), color),
			VertexFormat(vec3(0.5, -2, 0), color)
	};
	vector<unsigned short> tr_i{
		0,2,1
	};
	Mesh* tr = new Mesh(name);
	tr->InitFromData(tr_v, tr_i);
	return tr;
}
double random_number(int start, int end)
{
	double x = (double)rand() / RAND_MAX;
	return start + (end - start) * x;
}
void Tema1::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	
	//BOW
	{
		vec3 color = { 0,0,0 };
		vector<VertexFormat> bow_v = bow_form(color,0.5,1);
		vector<unsigned short> bow_i;
		for (int i = 0; i < bow_v.size(); i++)
			bow_i.push_back(i);
		Mesh* bow = new Mesh("bow");
		bow->SetDrawMode(GL_LINE_STRIP);
		bow->InitFromData(bow_v, bow_i);
		AddMeshToList(bow);
		arc.x = 100;
		arc.y = window->GetResolution().y / 2;
		vector<VertexFormat> bow_v_2 = {
				VertexFormat(vec3(0,1,0),color),
				VertexFormat(vec3(0,-1,0),color),
				VertexFormat(vec3(-1,0,0),color)
		};
		vector<unsigned short> bow_i_2 = {
			0,2,1
		};
		Mesh* bow_string = new Mesh("string");
		bow_string->SetDrawMode(GL_LINE_STRIP);
		bow_string->InitFromData(bow_v_2, bow_i_2);
		AddMeshToList(bow_string);
	}
	//ARROW
	{
		vec3 color = { 0, 0, 0 };
		vector<VertexFormat> arrow_v
		{
			VertexFormat(vec3(-2,0.5,0),color),
			VertexFormat(vec3(-2,-0.5,0),color),
			VertexFormat(vec3(0,0,0),color),
			VertexFormat(vec3(-10,0.05,0),color),
			VertexFormat(vec3(0,0.05,0),color),
			VertexFormat(vec3(0, -0.05, 0),color),
			VertexFormat(vec3(-10,-0.05,0),color)
		};
		vector<unsigned short> arrow_i{
			0, 2, 1,
			3, 5, 6,
			3, 4, 5
		};
		Mesh* arrow = new Mesh("arrow");
		arrow->InitFromData(arrow_v, arrow_i);
		AddMeshToList(arrow);
		s.x = arc.x + 100;
		s.y = 150;
	}
	//Red Balloon
	{
		vec3 color = { 1,0,0 };
		AddMeshToList(balloon(color, "RedBalloon"));

	}
	//BalloonTail
	{
		vec3 color = { 0,0,0 };
		vector<VertexFormat> tail_v = balloon_tail(color);
		vector<unsigned short> tail_i;
		for (int i = 0; i < tail_v.size(); i++)
			tail_i.push_back(i);
		Mesh* tail = new Mesh("tail");
		tail->SetDrawMode(GL_LINE_STRIP);
		tail->InitFromData(tail_v, tail_i);
		AddMeshToList(tail);
	}
	//Red BalloonTriangle
	{
		vec3 color=vec3(1,0,0);
		AddMeshToList(balloon_Triangle(color,"RedTriangle"));
		
	}
	//Yellow Balloon
	{
		vec3 color = { 1,1,0 };
		AddMeshToList(balloon(color, "YellowBalloon"));
	}
	//Yellow Balloon Triangle
	{
		vec3 color = vec3(1, 1, 0);
		AddMeshToList(balloon_Triangle(color, "YellowTriangle"));
	}
	//Shuriken
	{
		vec3 color = vec3(0.2,0.2,0.2);
		vector<VertexFormat> vertices{
			VertexFormat(vec3(0,0,0),color),
			VertexFormat(vec3(1,0,0),color),
			VertexFormat(vec3(0,1,0),color),
			VertexFormat(vec3(-1,0,0),color),
			VertexFormat(vec3(0,-1,0),color),
			VertexFormat(vec3(0.5,0.5,0),color),
			VertexFormat(vec3(-0.5,-0.5,0),color),
			VertexFormat(vec3(-0.5,0.5,0),color),
			VertexFormat(vec3(0.5,-0.5,0),color)
		};
		vector<unsigned short> indeces{
			0,1,5,
			0,2,7,
			0,3,6,
			0,4,8
		};
		Mesh* shuri = new Mesh("Shuriken");
		shuri->InitFromData(vertices, indeces);
		AddMeshToList(shuri);
	}
	//Power Bar
	{
		vector<VertexFormat> vertices{
			VertexFormat(vec3(0,0,0),vec3(1,1,0)),
			VertexFormat(vec3(1, 0, 0), vec3(1, 0, 0)),
			VertexFormat(vec3(0, 1, 0), vec3(1, 1, 0)),
			VertexFormat(vec3(1,1,0), vec3(1,0,0))
		};
		vector<unsigned short> indices{
			0,1,2,
			1,3,2
		};
		Mesh* power_bar = new Mesh("PowerBar");
		power_bar->InitFromData(vertices, indices);
		AddMeshToList(power_bar);
	}
}

void Tema1::FrameStart()
{
	glClearColor(0.1, 0.4, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	ivec2 resolution = window->GetResolution();
	glViewport(0, 0, resolution.x, resolution.y);
}

bool Tema1::colision_arrow_balloon(balon b, sageata a)
{
	float dx = b.x - a.x;
	float dy = b.y - a.y - sin(a.angle) * a.scale_y * arrow_len;
	float dist = sqrt(dx*dx + dy*dy);
	if (dist < b.scale_y * 1.75)
		return TRUE;
	return FALSE;
}
bool colision_bow_shuriken(arc a, shuriken s)
{
	float dx = a.x - s.x;
	float dy = a.y - s.y;
	float dist = sqrt(dx * dx + dy * dy);
	if (dist < a.scale + s.scale)
		return TRUE;
	return FALSE;
}
bool Tema1::colision_arrow_shuriken(sageata a, shuriken s)
{
	float dx = s.x - a.x;
	float dy = s.y - a.y - sin(a.angle) * a.scale_y * arrow_len;
	float dist = sqrt(dx * dx + dy * dy);
	if (dist < s.scale)
		return a.move;
	return FALSE;
}
void Tema1::balloon_move(balon* b, sageata s,bool isRed, float deltaTimeSeconds)
{
		if (colision_arrow_balloon(*b, s))
		{
			(*b).isBroken = TRUE;
		}
		if ((*b).isBroken && (*b).scale_x > 5)
		{
			(*b).scale_x -= deltaTimeSeconds * 10;
			(*b).y -= deltaTimeSeconds * (*b).gravitation;
			(*b).gravitation += 10;
		}

		if (!(*b).isBroken) {
			(*b).y += speed * 100 * deltaTimeSeconds;

			(*b).dx +=  deltaTimeSeconds*speed;
		}
		if ((*b).y > window->GetResolution().y)
		{
			(*b).x = random_number(300, window->GetResolution().x);
			(*b).y = 0;
		}
		modelMatrix = mat3(1);
		modelMatrix *= Transform2D::Translate((*b).x + sin((*b).dx)*zigzag, (*b).y);

		modelMatrix *= Transform2D::Scale((*b).scale_x, (*b).scale_y);
		if (isRed)
		{
			RenderMesh2D(meshes["RedBalloon"], shaders["VertexColor"], modelMatrix);
			RenderMesh2D(meshes["RedTriangle"], shaders["VertexColor"], modelMatrix);
			RenderMesh2D(meshes["tail"], shaders["VertexColor"], modelMatrix);
		}
		else {
			RenderMesh2D(meshes["YellowBalloon"], shaders["VertexColor"], modelMatrix);
			RenderMesh2D(meshes["YellowTriangle"], shaders["VertexColor"], modelMatrix);
			RenderMesh2D(meshes["tail"], shaders["VertexColor"], modelMatrix);
		}
}
void Tema1::generate_balloons(float deltaTimeSeconds, vector<balon> *balloons, float *time, int max, bool isRed)
{
	if ((*balloons).size() < max)
	{
		if (*time <= 0)
		{
			balon b;
			b.x = random_number(300, window->GetResolution().x);
			b.y = 0;
			(*balloons).push_back(b);
			*time = random_number(0, 10);
		}
		*time -= 0.1;
	}

	for (int i = 0; i < (*balloons).size(); i++)
	{
		balloon_move(&((*balloons)[i]), s, isRed, deltaTimeSeconds);
		if ((*balloons)[i].scale_x < 5 && (*balloons)[i].y < 0) {
			(*balloons).erase((*balloons).begin() + i);
			if (isRed)
				SCORE += 100;
			else SCORE -= 50;
			cout <<"SCORE IS: "<< SCORE<<"\n";
		}
	}
}
void Tema1::difficulty(int score)
{
	max_red_balloons = initial_red + score / 100;
	max_yellow_ballons = initial_yellow + score / 100;
	max_shurikens = initial_shurikens + score / 500;
	speed = initial_speed + (float) score / 1000;
	
	if (score > 1000)
		initial_red = 0;
}
bool Tema1::shuriken_move(float deltaTimeSeconds,shuriken *shuriken)
{
	if (colision_bow_shuriken(arc, (*shuriken)))
	{
		lives--;
		cout << lives << "LIVES LEFT\n";
		initial_speed -= 0.5;
		initial_shurikens--;
		return TRUE;
	}
	if (colision_arrow_shuriken(s,(*shuriken)))
	{
		SCORE += 100;
		cout << "SCORE IS: " << SCORE << "\n";
		return TRUE;
	}
	(*shuriken).x -= deltaTimeSeconds * 100 * speed;
	(*shuriken).angle += deltaTimeSeconds * speed;
	if ((*shuriken).x < 0) {
		return TRUE;
	}
	modelMatrix = mat3(1);
	modelMatrix *= Transform2D::Translate((*shuriken).x, (*shuriken).y);
	modelMatrix *= Transform2D::Rotate((*shuriken).angle);
	modelMatrix *= Transform2D::Scale(shuriken->scale, shuriken->scale);
	RenderMesh2D(meshes["Shuriken"], shaders["VertexColor"], modelMatrix);
	return FALSE;
}
void Tema1::generate_shurikens(float deltaTimeSeconds)
{
	if(stars.size() < max_shurikens)
	{
		shuriken star;
		star.x = window->GetResolution().x;
		star.y = random_number(0, window->GetResolution().y);
		stars.push_back(star);
	}
	for(int i = 0; i < stars.size();i++)
	{
		if(shuriken_move(deltaTimeSeconds, &stars[i]))
		{
			stars.erase(stars.begin() + i);
		}
		
	}
}

void Tema1::Update(float deltaTimeSeconds)
{
	difficulty(SCORE);
	if (lives > 0 && SCORE < 5000) {
		if (s.move)
		{
			s.x += deltaTimeSeconds * s.speed * 10 * cos(s.angle);
			s.y += deltaTimeSeconds * s.speed * 10 * sin(s.angle);
		}
		if (s.x - 100 > window->GetResolution().x || s.y > window->GetResolution().y || s.y < 0)
		{
			s.x = arc.x + 100;
			s.move = FALSE;
			s.scale_x = s.scale_y;
		}
		if (s.x <= arc.x + 100)
		{
			s.y = arc.y;
		}
		if (arc.angle > M_PI_4)
			arc.angle = M_PI_4;
		if (arc.angle < -M_PI_4)
			arc.angle = -M_PI_4;
		modelMatrix = mat3(1);
		modelMatrix *= Transform2D::Translate(s.x, s.y);
		if (!s.move) {
			s.angle = arc.angle;
		}
		modelMatrix *= Transform2D::Translate(-100, 0);
		modelMatrix *= Transform2D::Rotate(s.angle);
		modelMatrix *= Transform2D::Translate(100, 0);
		modelMatrix *= Transform2D::Scale(s.scale_x, s.scale_y);
		RenderMesh2D(meshes["arrow"], shaders["VertexColor"], modelMatrix);
		modelMatrix = mat3(1);
		modelMatrix *= Transform2D::Translate(arc.x, arc.y);
		modelMatrix *= Transform2D::Rotate(arc.angle);
		modelMatrix *= Transform2D::Scale(arc.scale, arc.scale);
		RenderMesh2D(meshes["bow"], shaders["VertexColor"], modelMatrix);
		modelMatrix = mat3(1);
		modelMatrix *= Transform2D::Translate(arc.x, arc.y);
		modelMatrix *= Transform2D::Rotate(arc.angle);
		modelMatrix *= Transform2D::Scale(bow_scale, arc.scale);
		RenderMesh2D(meshes["string"], shaders["VertexColor"], modelMatrix);
		
		generate_balloons(deltaTimeSeconds, &red_balloons, &time_for_red_ballons, max_red_balloons, TRUE);
		generate_balloons(deltaTimeSeconds, &yellow_ballons, &time_for_yellow_ballons, max_yellow_ballons, FALSE);
		generate_shurikens(deltaTimeSeconds);
				
		modelMatrix = mat3(1);
		modelMatrix *= Transform2D::Translate(arc.x, arc.y - 130);
		modelMatrix *= Transform2D::Scale(power_L, power_l);
		RenderMesh2D(meshes["PowerBar"], shaders["VertexColor"], modelMatrix);
	}
	if(lives == 0 && afisare)
	{
		cout << "\n\nYOU LOST!\nSCORE: " << SCORE << "\n\n";
		afisare = FALSE;
	}
	if(SCORE > 5000 && afisare)
	{
		cout << "\n\n YOU WIN!\n\n";
		afisare = TRUE;
	}
}

void Tema1::FrameEnd()
{
	
}

void Tema1::OnInputUpdate(float deltaTime, int mods)
{
	if(window->MouseHold(0))
	{
		if(power_l == 0)
		{
			power_l = power_L = 20;
		}
		if (power_L < 100) {
			power_L += deltaTime * 20;
			bow_scale += deltaTime * 10;
			s.scale_x += deltaTime;
		}
	}
	if (window->KeyHold(GLFW_KEY_W))
		if(arc.y + 100 < window->GetResolution().y - 10)
			arc.y += deltaTime * 100 * speed;
	if (window->KeyHold(GLFW_KEY_S))
		if(arc.y - 100 > 10)
			arc.y -= deltaTime * 100 * speed;
}

void Tema1::OnKeyPress(int key, int mods)
{
	// add key press event
}

void Tema1::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
	arc.angle = atan(((window->GetResolution().y-mouseY)-arc.y) / (mouseX - arc.x));
	if (mouseX < arc.x)
		if (window->GetResolution().y - mouseY < arc.y)
			arc.angle = -M_PI_4;
		else
			arc.angle = M_PI_4;
	
}

void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
	if(IS_BIT_SET(button,GLFW_MOUSE_BUTTON_LEFT))
	{
		if (!s.move) {
			s.speed = power_L;
			s.move = TRUE;
		}
		power_l = power_L = 0;
		bow_scale = 1;
		
	}
}

void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema1::OnWindowResize(int width, int height)
{
}