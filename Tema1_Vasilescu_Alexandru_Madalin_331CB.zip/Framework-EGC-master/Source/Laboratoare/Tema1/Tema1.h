#pragma once
#include <Component/SimpleScene.h>
#include <string>
#include <Core/Engine.h>
#include <vector>
#include <iostream>

struct balon
{
	float x, y;
	float dx = 0;
	bool isBroken = FALSE;
	float scale_x = 20;
	float scale_y = 20;
	float gravitation = 100;
};
struct sageata
{
	float x, y;
	float speed;
	bool move = FALSE;
	float angle;
	float scale_x = 10;
	float scale_y = 10;
};
struct shuriken
{
	float x, y;
	float angle = 0;
	float scale = 50;
	float hits = 2;
};
struct arc
{
	float x, y;
	float angle;
	float scale = 100;
};
class Tema1 : public SimpleScene
{
public:
	Tema1();
	~Tema1();

	void Init() override;

private:
	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;

	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;
	void balloon_move(balon *b, sageata s,bool isRed, float deltaTimeSeconds);
	void generate_balloons(float deltaTimeSeconds, std::vector<balon> *balloons, float *time, int max, bool isRed);
	void difficulty(int score);
	void generate_shurikens(float deltaTimeSeconds);
	bool shuriken_move(float deltaTimeSeconds, shuriken *shuriken);
	bool colision_arrow_balloon(balon b, sageata a);
	bool colision_arrow_shuriken(sageata a, shuriken s);
	
protected:
	int SCORE;
	int lives = 3;
	bool afisare = TRUE;
	glm::mat3 modelMatrix;

	//POWER BAR
	float power_L,power_l;

	//ARC
	float bow_scale = 1;
	arc arc;

	//sageata
	sageata s;
	float arrow_len = 10;

	//balon
	float zigzag = 50;
	
	//RED BALLOONS PARAM
	std::vector<balon> red_balloons;
	float time_for_red_ballons;
	int max_red_balloons;
	int initial_red = 5;
	
	//YELLOW BALLOONS PARAM
	std::vector<balon> yellow_ballons;
	float time_for_yellow_ballons;
	int max_yellow_ballons;
	int initial_yellow = 0;

	//SHURIKEN
	std::vector<shuriken> stars;
	int max_shurikens;
	int initial_shurikens = 0;

	//ALL
	float speed;
	float initial_speed = 1.5;
};
